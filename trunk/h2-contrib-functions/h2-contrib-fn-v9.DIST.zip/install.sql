CREATE ALIAS DATE FOR org.h2.contrib.fn.MysqlTimeDate.date ;
CREATE ALIAS UNIX_TIMESTAMP FOR org.h2.contrib.fn.MysqlTimeDate.unixTimestamp ;
CREATE ALIAS FROM_UNIXTIME FOR org.h2.contrib.fn.MysqlTimeDate.fromUnixTime ;